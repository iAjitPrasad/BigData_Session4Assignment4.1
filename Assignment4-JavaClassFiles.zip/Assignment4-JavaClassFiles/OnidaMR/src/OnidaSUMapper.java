import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class OnidaSUMapper
	extends Mapper<Object, Text, Text,IntWritable>
		{

	      private Text word = new Text();
	      private final static IntWritable one = new IntWritable(1);

	 	  public void map(Object key, Text value, Context context) 
	 			  throws IOException, InterruptedException 
						{
							String record = value.toString();
							if (record.length() > 0) 
							{	      
								StringTokenizer st = new StringTokenizer(record, "|");
								String company= st.nextToken();
								String product= st.nextToken();
								st.nextToken();
								String state = st.nextToken();
	 			     
								if ("NA".equals(company) || "NA".equals(product)) 
								{
								// Skip the Record as it is invalid
	 			    	
								} 
								
								else if ("Onida".equals(company))
								{			     
									word.set(state);
									context.write(word, one);
								}
	              
							}

						}

		}
