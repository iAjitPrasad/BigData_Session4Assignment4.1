import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapperOne extends Mapper<LongWritable, Text, Text, IntWritable> {
	
	Text outKey = new Text();
	IntWritable outValue = new IntWritable();
	
	public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException{
		
		String[] line = value.toString().split("\\|");
		outKey.set(line[0]);
		outValue.set(1);
		con.write(outKey, outValue);
		
	}
}
